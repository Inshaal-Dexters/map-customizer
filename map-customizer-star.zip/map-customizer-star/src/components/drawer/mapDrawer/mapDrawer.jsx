import { useEffect, useMemo, useState } from "react";
import {
  AccordionDetails,
  Autocomplete,
  Box,
  Button,
  Divider,
  MenuItem,
  Paper,
  TextField,
  Typography,
} from "@mui/material";
import {
  AccordionHeading,
  CustomAccordion,
  DrawerHeader,
  LogoContainer,
  ProductTypes,
  CustomDrawer,
  ScrollContainer,
  FrameWrapper,
  OpenButton,
  CloseButton,
  CustomButton,
  DrawerFooter,
  NumberFelid,
  MapStyleWrapper,
  MarkerContainer,
  MarkersWrapper,
  Icon,
} from "./mapDrawerStyledComp";

import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import DoNotDisturbIcon from "@mui/icons-material/DoNotDisturb";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import axios from "axios";
import { starData, layout, types, mapData } from "../../data/data";
import { ChromePicker } from "react-color";
import Switch from "@mui/material/Switch";
import MaterialDetails from "../../materialDetails/materialDetails";
import { scrapData } from "../../../helper/scrapData";
import { htmlToBlobConvert } from "../../../commons/imgConverter";

const MapDrawer = ({
  frameDesign,
  setFrameDesign,
  frameText,
  setFrameText,
  setIsLoading,
  elementRef,
}) => {
  const [expanded, setExpanded] = useState(1);
  const [drawerOpen, setDrawerOpen] = useState(true);
  const totalArea = useMemo(() => {
    let height = +frameDesign.size.height;
    let width = +frameDesign.size.width;
    return (width * height) / 144;
  }, [frameDesign]);
  const checkoutTotal = useMemo(
    () =>
      ((frameDesign.size.width * frameDesign.size.height) / 144) *
      frameDesign.price,
    [frameDesign]
  );
  const [suggestions, setSuggestions] = useState([]);
  const [locationName, setLocationName] = useState("");
  const [debouncedValue, setDebouncedValue] = useState({
    width: "",
    height: "",
  });
  const getSuggestions = async (value) => {
    try {
      const response = await axios.get(
        `https://api.locationiq.com/v1/autocomplete?key=pk.8d19b1ef7170725976c6f53e5c97774c&q=${value}&limit=5&dedupe=1`
      );
      if (response.data && response.data.length > 0) {
        return response.data.map((result) => result.display_name);
      } else {
        return [];
      }
    } catch (error) {
      console.error("Error fetching location suggestions:", error);
      return [];
    }
  };
  const handleLocationChange = (event, newValue) => {
    setLocationName(newValue);
  };
  const getLocationCoordinates = async (value) => {
    try {
      const response = await axios.get(
        `https://api.locationiq.com/v1/autocomplete?key=pk.8d19b1ef7170725976c6f53e5c97774c&q=${value}&limit=5&dedupe=1`
      );
      if (response.data && response.data.length > 0) {
        const firstResult = response.data[0];
        setFrameDesign({
          ...frameDesign,
          lon: firstResult.lon,
          lat: firstResult.lat,
          zoom: 12,
        });
        setFrameText({
          ...frameText,
          lon: firstResult.lon,
          lat: firstResult.lat,
        });
      } else {
        alert("Location not found");
      }
    } catch (error) {
      console.error("Error fetching location data:", error);
    }
  };

  const handleLocationSelection = (event, newValue) => {
    getLocationCoordinates(newValue);
  };

  const handleSizeChange = (e, cordinate) => {
    if (typeof +e.target.value === "number") {
      clearTimeout(debouncedValue[cordinate]);
      const layoutNow =
        cordinate === "width"
          ? frameDesign.size.height > +e.target.value
            ? layout.portrait
            : frameDesign.size.height < +e.target.value
            ? layout.landscape
            : layout.square
          : frameDesign.size.width > +e.target.value
          ? layout.landscape
          : frameDesign.size.width < +e.target.value
          ? layout.portrait
          : layout.square;

      const timeoutId = setTimeout(() => {
        setFrameDesign({
          ...frameDesign,
          size: {
            ...frameDesign.size,
            [cordinate]: +e.target.value,
          },
          layout: layoutNow,
        });
      }, 1000);
      setDebouncedValue({ ...debouncedValue, [cordinate]: timeoutId });
    }
  };
  return (
    <>
      <OpenButton onClick={() => setDrawerOpen(true)} color="white">
        <KeyboardArrowRightIcon />
      </OpenButton>
      <CustomDrawer anchor="left" variant="persistent" open={drawerOpen}>
        <DrawerHeader>
          <Box display="flex" alignItems="center">
            <LogoContainer>LOGO</LogoContainer>
            <CloseButton onClick={() => setDrawerOpen(false)}>
              <KeyboardArrowLeftIcon />
            </CloseButton>
          </Box>
          <Box>
            <Typography variant="h4" component="h4" textAlign="center">
              Design Your Universe
            </Typography>
            <Typography
              textAlign="center"
              fontStyle="italic"
              variant="subtitle1"
            >
              Create a Custom City Map for Your Special Moment!
            </Typography>
          </Box>
          <Divider sx={{ mb: "10px" }} />
        </DrawerHeader>
        <Box overflow="auto">
          <CustomAccordion
            expanded={expanded === 1}
            onChange={() => setExpanded(expanded === 1 ? 0 : 1)}
          >
            <AccordionHeading expandIcon={<ExpandMoreIcon />}>
              <Typography>Location & Markers</Typography>
            </AccordionHeading>
            <AccordionDetails>
              <Autocomplete
                freeSolo
                id="location-autocomplete"
                disableClearable
                options={suggestions}
                inputValue={locationName}
                onInputChange={(event, newValue) => {
                  handleLocationChange(event, newValue);
                  getSuggestions(newValue).then((suggestions) => {
                    setSuggestions(suggestions);
                  });
                }}
                onChange={handleLocationSelection}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Enter Location"
                    InputProps={{
                      ...params.InputProps,
                      type: "search",
                    }}
                  />
                )}
              />

              <Box
                sx={{
                  m: "10px auto",
                  fontWeight: "600",
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                Markers
                <Switch
                  checked={frameDesign.showMarker}
                  onChange={() =>
                    setFrameDesign({
                      ...frameDesign,
                      showMarker: !frameDesign.showMarker,
                    })
                  }
                />
              </Box>
              <Typography sx={{ m: "10px" }} fontStyle="italic" fontSize="12px">
                <strong>NOTE:</strong> Select icon here and click anywhere on
                the map to place marker
              </Typography>
              <Divider sx={{ m: "10px" }} />
              <MarkerContainer>
                <MarkersWrapper elevation={4}>
                  {mapData.markerIcons.map((icon, k) => (
                    <Icon
                      icon_color={`rgba(${frameDesign.markerColor.r},${frameDesign.markerColor.g},${frameDesign.markerColor.b},${frameDesign.markerColor.a})`}
                      key={k}
                      elevation={frameDesign.marker === k ? 12 : 4}
                      onClick={(e) =>
                        setFrameDesign({ ...frameDesign, marker: k })
                      }
                    >
                      {icon}
                    </Icon>
                  ))}
                </MarkersWrapper>
                <ChromePicker
                  color={frameDesign.markerColor}
                  onChange={(value) => {
                    setFrameDesign({ ...frameDesign, markerColor: value.rgb });
                  }}
                />
              </MarkerContainer>
            </AccordionDetails>
          </CustomAccordion>

          <CustomAccordion
            expanded={expanded === 2}
            onChange={() => setExpanded(expanded === 2 ? 0 : 2)}
          >
            <AccordionHeading expandIcon={<ExpandMoreIcon />}>
              <Typography>Text</Typography>
            </AccordionHeading>
            <AccordionDetails>
              <Typography sx={{ m: "10px" }} fontStyle="italic" fontSize="12px">
                Add a personal message (optional):
              </Typography>
              <Divider sx={{ m: "10px" }} />
              <Box>
                <TextField
                  id="outlined-multiline-flexible"
                  label="Title"
                  multiline
                  maxRows={4}
                  sx={{ minWidth: "100%" }}
                  value={frameText.title}
                  onChange={(e) =>
                    setFrameText({
                      ...frameText,
                      title: e.target.value,
                    })
                  }
                />
              </Box>
              <Divider sx={{ m: "10px" }} />
              <Box>
                <TextField
                  label="Sub Title"
                  placeholder="Type your location Here it won't effect the location of Map"
                  sx={{ width: "100%" }}
                  value={frameText.subTitle}
                  onChange={(e) =>
                    setFrameText({
                      ...frameText,
                      subTitle: e.target.value,
                    })
                  }
                />
              </Box>
              <Divider sx={{ m: "10px" }} />
              <Box sx={{ display: "flex", justifyContent: "space-around" }}>
                <TextField
                  label="Longitude"
                  placeholder="Longitude here!"
                  sx={{ width: "40%" }}
                  value={frameText.lon}
                  onChange={(e) =>
                    setFrameText({
                      ...frameText,
                      lon: e.target.value,
                    })
                  }
                />
                <TextField
                  label="latitude"
                  placeholder="latitude here!"
                  sx={{ width: "40%" }}
                  value={frameText.lat}
                  onChange={(e) =>
                    setFrameText({
                      ...frameText,
                      lat: e.target.value,
                    })
                  }
                />
              </Box>
              <Box
                sx={{ m: "10px", display: "flex", justifyContent: "center" }}
              >
                <ChromePicker
                  color={frameDesign.textColor}
                  onChange={(value) => {
                    setFrameDesign({ ...frameDesign, textColor: value.rgb });
                  }}
                />
              </Box>
            </AccordionDetails>
          </CustomAccordion>

          <CustomAccordion
            expanded={expanded === 3}
            onChange={() => setExpanded(expanded === 3 ? 0 : 3)}
          >
            <AccordionHeading expandIcon={<ExpandMoreIcon />}>
              <Typography>Product Type</Typography>
            </AccordionHeading>
            <AccordionDetails>
              <Box display="flex" justifyContent="space-around">
                {starData.type.map(({ name, svg }, k) => (
                  <ProductTypes
                    key={k}
                    elevation={frameDesign.type === name ? 12 : 2}
                    onClick={() =>
                      name === types.mural
                        ? setFrameDesign((prev) => ({
                            ...prev,
                            type: name,
                            material: starData.material[name][0].title,
                          }))
                        : setFrameDesign((prev) => ({
                            ...prev,
                            type: name,
                            size: starData.size[frameDesign.layout][1],
                            material: starData.material[name][0].title,
                          }))
                    }
                  >
                    {svg}
                    <Typography sx={{ alignSelf: "center" }}>{name}</Typography>
                  </ProductTypes>
                ))}
              </Box>

              {frameDesign.type === types.mural ? (
                <>
                  <Typography
                    sx={{ m: "10px" }}
                    fontStyle="italic"
                    fontSize="12px"
                  >
                    Select mural size (minimum size: 25 ft²)
                  </Typography>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-around",
                      alignItems: "center",
                    }}
                  >
                    <NumberFelid
                      size="standard"
                      type="number"
                      helperText="inch"
                      label="width"
                      defaultValue={frameDesign.size.width}
                      onWheel={(e) => e.target.blur()}
                      onChange={(e) => handleSizeChange(e, "width")}
                    />
                    <Box>x</Box>
                    <NumberFelid
                      size="standard"
                      type="number"
                      label="height"
                      helperText="inch"
                      defaultValue={frameDesign.size.height}
                      onWheel={(e) => e.target.blur()}
                      onChange={(e) => handleSizeChange(e, "height")}
                    />
                    <Typography>Area = {totalArea.toFixed(2)}ft²</Typography>
                  </Box>
                </>
              ) : (
                <>
                  <Box sx={{ m: "10px auto", fontWeight: "600" }}>
                    Choose Layout
                  </Box>
                  <Box sx={{ display: "flex", justifyContent: "space-around" }}>
                    {starData.layout.map((name, k) => (
                      <CustomButton
                        key={k}
                        variant={
                          frameDesign.layout === name ? "contained" : "outlined"
                        }
                        onClick={() =>
                          setFrameDesign((prev) => ({
                            ...prev,
                            layout: name,
                            size: starData.size[name][1],
                          }))
                        }
                      >
                        {name}
                      </CustomButton>
                    ))}
                  </Box>
                  {frameDesign.type !== types.jpg && (
                    <>
                      <Box sx={{ m: "10px auto", fontWeight: "600" }}>
                        Choose Size
                      </Box>
                      <Box
                        sx={{ display: "flex", justifyContent: "space-around" }}
                      >
                        {starData.size[frameDesign.layout].map((val, k) => (
                          <CustomButton
                            key={k}
                            variant={
                              frameDesign.size.width === val.width
                                ? "contained"
                                : "outlined"
                            }
                            onClick={() =>
                              setFrameDesign((prev) => ({ ...prev, size: val }))
                            }
                            sx={{ textTransform: "lowercase" }}
                          >
                            {val.width}x{val.height}
                          </CustomButton>
                        ))}
                      </Box>
                    </>
                  )}
                </>
              )}
            </AccordionDetails>
          </CustomAccordion>

          <CustomAccordion
            expanded={expanded === 4}
            onChange={() => setExpanded(expanded === 4 ? 0 : 4)}
          >
            <AccordionHeading expandIcon={<ExpandMoreIcon />}>
              <Typography>Product Style</Typography>
            </AccordionHeading>
            <AccordionDetails>
              <Box sx={{ m: "10px auto", fontWeight: "600" }}>Maps</Box>
              <ScrollContainer
                variant="scrollable"
                value={0}
                scrollButtons
                allowScrollButtonsMobile
              >
                {mapData.mapStyle.map((style, k) => (
                  <MapStyleWrapper
                    key={k}
                    elevation={style.link === frameDesign.mapStyle ? 12 : 2}
                    onClick={() => {
                      setFrameDesign({ ...frameDesign, mapStyle: style.link });
                    }}
                  >
                    <img src={style.img} alt={style.name} />
                    <Typography>{style.name}</Typography>
                  </MapStyleWrapper>
                ))}
              </ScrollContainer>
              <Box sx={{ m: "10px auto", fontWeight: "600" }}>Frame Style</Box>
              <ScrollContainer
                variant="scrollable"
                value={0}
                scrollButtons
                allowScrollButtonsMobile
              >
                {mapData.frameStyle.map((data, k) => (
                  <MapStyleWrapper
                    key={k}
                    elevation={data.name === frameDesign.frameStyle ? 12 : 2}
                    onClick={() => {
                      setFrameDesign({ ...frameDesign, frameStyle: data.name });
                    }}
                  >
                    <img src={data.img} alt={data.name} />
                    <Typography>{data.name}</Typography>
                  </MapStyleWrapper>
                ))}
              </ScrollContainer>

              <Box sx={{ m: "10px auto", fontWeight: "600" }}>Frame Colors</Box>
              <Box sx={{ display: "flex", justifyContent: "center" }}>
                <ChromePicker
                  color={frameDesign.frameColor}
                  onChange={(value) => {
                    setFrameDesign({ ...frameDesign, frameColor: value.rgb });
                  }}
                />
              </Box>
            </AccordionDetails>
          </CustomAccordion>

          <CustomAccordion
            expanded={expanded === 5}
            onChange={() => setExpanded(expanded === 5 ? 0 : 5)}
          >
            <AccordionHeading expandIcon={<ExpandMoreIcon />}>
              <Typography>Product Material</Typography>
            </AccordionHeading>
            <AccordionDetails>
              <Divider sx={{ m: "10px" }} />
              <Box sx={{ m: "10px auto", fontWeight: "600" }}>
                Material & Finishing
              </Box>
              <Typography sx={{ m: "10px" }} fontStyle="italic" fontSize="12px">
                Select print material and finishing options
              </Typography>
              <Divider sx={{ m: "10px" }} />

              <TextField
                label="Material"
                select
                value={frameDesign.material}
                size="standard"
                sx={{ width: "100%" }}
                onChange={(e) => {
                  const materialDetails = starData.material[
                    frameDesign.type
                  ].find((option) => option.title === e.target.value);

                  setFrameDesign({
                    ...frameDesign,
                    material: e.target.value,
                    price: materialDetails.rate,
                  });
                }}
              >
                {starData.material[frameDesign.type].map((option, k) => (
                  <MenuItem key={k} value={option.title}>
                    {option.title}
                  </MenuItem>
                ))}
              </TextField>
              <MaterialDetails frameDesign={frameDesign} />
            </AccordionDetails>
          </CustomAccordion>

          {frameDesign.type === types.frame ? (
            <CustomAccordion
              expanded={expanded === 6}
              onChange={() => setExpanded(expanded === 6 ? 0 : 6)}
            >
              <AccordionHeading expandIcon={<ExpandMoreIcon />}>
                <Typography>Frames</Typography>
              </AccordionHeading>
              <AccordionDetails>
                {/* <Divider sx={{ m: "10px" }} /> */}
                <Box sx={{ m: "10px auto", fontWeight: "600" }}>
                  Choose Frame
                </Box>
                <ScrollContainer
                  variant="scrollable"
                  value={0}
                  scrollButtons
                  allowScrollButtonsMobile
                >
                  <Paper
                    sx={{
                      minWidth: "130px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                    elevation={frameDesign.frame.img === "" ? 12 : 2}
                    onClick={() =>
                      setFrameDesign({
                        ...frameDesign,
                        frame: {
                          img: "",
                          name: "",
                          price: 0,
                        },
                      })
                    }
                  >
                    <DoNotDisturbIcon sx={{ fill: "red", fontSize: "80px" }} />
                  </Paper>

                  {starData.frames.map((frame, k) => (
                    <FrameWrapper
                      key={k}
                      elevation={frame.img === frameDesign.frame.img ? 12 : 2}
                      onClick={() =>
                        setFrameDesign({
                          ...frameDesign,
                          frame: {
                            img: frame.img,
                            name: frame.name,
                            price: frame.price,
                          },
                        })
                      }
                    >
                      <img
                        src={frame.img}
                        alt="frame"
                        width={"100px"}
                        height={"130px"}
                      />
                      {frame.name}
                    </FrameWrapper>
                  ))}
                </ScrollContainer>
              </AccordionDetails>
            </CustomAccordion>
          ) : (
            <></>
          )}
        </Box>

        <DrawerFooter>
          <Divider sx={{ m: "10px" }} />
          <Box sx={{}}>
            <Box sx={{ display: "flex", justifyContent: "space-between" }}>
              <Typography> {frameDesign.type} </Typography>
              <Typography>${checkoutTotal.toFixed(2)}</Typography>
            </Box>
            {frameDesign.frame.img ? (
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Box>{frameDesign.frame.name}</Box>
                <Typography>${frameDesign.frame.price}</Typography>
              </Box>
            ) : (
              ""
            )}
          </Box>
          <Divider sx={{ m: "10px" }} />
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              fontWeight: "600",
              marginBottom: "10px",
            }}
          >
            <Typography>Subtotal</Typography>
            <Box>${(frameDesign.frame.price + checkoutTotal).toFixed(2)}</Box>
          </Box>
          <Box sx={{ display: "flex", justifyContent: "end" }}>
            <Button
              variant="contained"
              onClick={async () => {
                setIsLoading(true);
                const dataUrl = await htmlToBlobConvert(
                  elementRef
                );
                scrapData(
                  frameDesign,
                  (frameDesign.frame.price + checkoutTotal).toFixed(2),
                  dataUrl,
                  setIsLoading
                );
              }}
            >
              Check Out <ArrowForwardIcon />
            </Button>
          </Box>
        </DrawerFooter>
      </CustomDrawer>
    </>
  );
};

export default MapDrawer;
