import {
  Accordion,
  AccordionSummary,
  Box,
  Button,
  Drawer,
  Paper,
  Tabs,
  TextField,
} from "@mui/material";
import { styled } from "styled-components";

export const CustomDrawer = styled(Drawer)`
  .MuiDrawer-paper {
    background: #f2f2f5;
    max-width: 100vw;
    @media (min-width: 500px) {
      max-width: 500px;
    }
  }
`;

export const DrawerHeader = styled(Box)`
  position: sticky;
  top: 0;
  left: 0;
  z-index: 2;
  background: #f2f2f5;
`;

export const DrawerFooter = styled(Box)`
  position: sticky;
  bottom: 0;
  left: 0;
  z-index: 2;
  background: #f2f2f5;
  margin: 15px;
`;

export const LogoContainer = styled(Box)`
  width: 50px;
  height: 50px;
  border: 1px solid grey;
  border-radius: 50%;
  margin: 8px auto;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const CustomAccordion = styled(Accordion)`
  margin: 0 !important;
`;

export const AccordionHeading = styled(AccordionSummary)`
  background: #f2f2f58c !important;
`;

export const ProductTypes = styled(Paper)`
  display: flex;
  gap: 10px;
  padding: 10px;
  margin: 5px;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  width: 120px;
  height: 120px;
  color: #808080 !important;
  cursor: pointer;
  svg {
    fill: #808080;
    font-size: 80px;
  }
  @media (max-width: 440px) {
    width: 100px;
    height: 100px;
    font-size: 14px;
    white-space: nowrap;
    svg {
      font-size: 60px;
    }
  }
`;

export const MapStyleWrapper = styled(Paper)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  cursor: pointer;
  gap: 10px;
  padding: 10px;
  img {
    height: 100px;
    width: 80px;
  }
`;

export const StyleColors = styled(Box)`
  min-width: 80px;
  min-height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
`;

export const MapColors = styled(Box)`
  min-width: 80px;
  min-height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
`;

export const MapColorWrapper = styled(Paper)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  cursor: pointer;
  gap: 10px;
  padding: 10px;
  img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
  }
`;

export const ScrollContainer = styled(Tabs)`
  span {
    background: transparent;
  }
  .MuiTabs-flexContainer {
    gap: 18px;
    padding: 20px;
  }
`;

export const FrameWrapper = styled(Paper)`
  min-width: 130px;
  min-height: 150px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 15px;
  padding-bottom: 10px;
  padding-top: 10px;
  font-weight: 500;
  font-variant: small-caps;
`;

export const OpenButton = styled(Button)`
  position: absolute !important;
  top: 15px;
  left: 15px;
  @media (max-width: 520px) {
    left: 10px;
  }
  @media (max-width: 450px) {
    left: 5px;
  }
`;

export const CloseButton = styled(Button)`
  @media (min-width: 1025px) {
    display: none !important;
  }
`;

export const CustomButton = styled(Button)`
  @media (max-width: 440px) {
    font-size: 12px !important;
  }
  @media (max-width: 375px) {
    font-size: 11px !important;
  }
`;

export const NumberFelid = styled(TextField)`
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  input[type="number"] {
    -moz-appearance: textfield;
  }
  width: 90px;
`;

export const MarkerContainer = styled(Box)`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: 20px;
  .chrome-picker {
    width: 200px !important;
    margin: 10px 0px;
  }
`;
export const MarkersWrapper = styled(Paper)`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  border-radius: 8px;
  gap: 20px;
  width: 200px;
  padding: 10px;
`;
export const Icon = styled(Paper)`
  cursor: pointer;
  border-radius: 50% !important;
  padding: 5px;
  display: flex;
  justify-content: center;
  align-items: center;

  svg {
    font-size: 30px;
    fill: ${({ icon_color }) => icon_color};
  }
`;
