import React from "react";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";
import styled from "@emotion/styled";
import { createPortal } from "react-dom";

const Loader = ({ isLoading = false }) => {
  return createPortal(
    <>
      {isLoading ? (
        <LoaderContainer>
          <CircularProgress color="white" />
        </LoaderContainer>
      ) : (
        <></>
      )}
    </>,
    document.body
  );
};

const LoaderContainer = styled(Box)`
  width: 100vw;
  height: 100vh;
  position: absolute;
  top: 0;
  left: 0;
  background-color: #80808091;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999999;
`;

export default Loader;
