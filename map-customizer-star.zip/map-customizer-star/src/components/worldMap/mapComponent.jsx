import { useMemo, useRef, useEffect } from "react";
import { Marker, useMapEvents, useMap } from "react-leaflet";

export const MarkerComponent = ({
  customIcon,
  frameDesign,
  setFrameDesign,
}) => {
  const markerRef = useRef(null);
  useMapEvents({
    click: (e) => {
      setFrameDesign({
        ...frameDesign,
        markerLat: e.latlng.lat,
        markerLon: e.latlng.lng,
      });
    },
  });
  const eventHandlers = useMemo(() => ({
    dragend() {
      const marker = markerRef.current;
      setFrameDesign({
        ...frameDesign,
        markerLat: marker.getLatLng().lat,
        markerLon: marker.getLatLng().lng,
      });
    },
  }));
  return (
    <>
      {frameDesign.showMarker ? (
        <Marker
          position={[frameDesign.markerLat, frameDesign.markerLon]}
          icon={customIcon}
          draggable
          eventHandlers={eventHandlers}
          ref={markerRef}
        />
      ) : (
        <></>
      )}
    </>
  );
};
export const MapUpdate = ({ frameDesign, center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    map.flyTo(center, zoom);
  }, [frameDesign.lat, frameDesign.lon]);

  return null;
};

export const GetCoordinates = ({ frameDesign, setFrameDesign }) => {
  useMapEvents({
    dragend: (e) => {
      setFrameDesign({
        ...frameDesign,
        lat: e.target.getCenter().lat,
        lon: e.target.getCenter().lng,
        zoom: e.target.getZoom(),
      });
    },
    zoom: (e) => {
      setFrameDesign({
        ...frameDesign,
        zoom: e.target.getZoom(),
      });
    },
  });
  return null;
};
