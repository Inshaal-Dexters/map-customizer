import { MapContainer, TileLayer } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { mapData } from "../data/data";
import { renderToStaticMarkup } from "react-dom/server";
import { MarkerComponent, GetCoordinates, MapUpdate } from "./mapComponent";

const WorldMap = ({ frameDesign, setFrameDesign }) => {
  const customIcon = new L.divIcon({
    className: "custom-icon",
    html: renderToStaticMarkup(
      <div
        style={{
          color: `rgba(${frameDesign.markerColor.r},${frameDesign.markerColor.g},${frameDesign.markerColor.b},${frameDesign.markerColor.a})`,
          transform: "scale(1.5)",
        }}
      >
        {mapData.markerIcons[frameDesign.marker]}
      </div>
    ),
  });
  return (
    <MapContainer
      zoom={frameDesign.zoom}
      key={frameDesign.layout}
      center={[frameDesign.lat, frameDesign.lon]}
      style={{ width: "100%", height: "100%", zIndex: "0" }}
    >
      <GetCoordinates
        frameDesign={frameDesign}
        setFrameDesign={setFrameDesign}
      />
      <MapUpdate
        center={[frameDesign.lat, frameDesign.lon]}
        zoom={frameDesign.zoom}
        frameDesign={frameDesign}
      />
      <TileLayer
        url={`https://api.mapbox.com/styles/v1/${frameDesign.mapStyle}/tiles/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiaHV6YWlmYS1zYXR0YXIxIiwiYSI6ImNsbmxuYWw2cjJkNWsycW1uZjYwOTBwMjMifQ.TD-iSu8sZaaupCGxvm4oAQ`}
      />
      <MarkerComponent
        customIcon={customIcon}
        frameDesign={frameDesign}
        setFrameDesign={setFrameDesign}
      />
    </MapContainer>
  );
};
export default WorldMap;
