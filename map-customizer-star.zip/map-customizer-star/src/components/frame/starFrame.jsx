import {
  Frame,
  FrameContainer,
  FrameOutline,
  ImageContainer,
  TextContainer,
  TextContent,
} from "./starFrameStyledComp";
import StarMap from "../starMap/starMap";
import { Box, IconButton } from "@mui/material";
import { layout, types } from "../data/data";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import Loader from "../loader/loader";
import { htmlToImageConvert } from "../../commons/imgConverter";

const StarFrame = ({
  frameDesign,
  frameText,
  isLoading,
  setIsLoading,
  elementRef,
}) => {
  return (
    <>
      <Frame>
        <Loader isLoading={isLoading} />
        <FrameContainer
          size={frameDesign.size}
          orientation={frameDesign.layout}
          frame_color={frameDesign.frameColor}
          ref={elementRef}
        >
          {frameDesign.type !== types.frame || frameDesign.frame.img === "" ? (
            <></>
          ) : (
            <ImageContainer
              src={frameDesign.frame.img}
              alt="frame"
              orientation={frameDesign.layout}
              height={
                frameDesign.layout === layout.square
                  ? 612
                  : frameDesign.layout === layout.landscape
                  ? 530.5
                  : 719
              }
              width={
                frameDesign.layout === layout.square
                  ? 680
                  : frameDesign.layout === layout.landscape
                  ? 800.5
                  : 590
              }
            />
          )}
          <FrameOutline
            orientation={frameDesign.layout}
            outline_color={frameDesign.outlineColor}
            height={
              frameDesign.layout === layout.square
                ? 450
                : frameDesign.layout === layout.landscape
                ? 382
                : 540
            }
            width={
              frameDesign.layout === layout.square
                ? 450
                : frameDesign.layout === layout.landscape
                ? 540
                : 382
            }
          >
            {frameDesign.layout === layout.portrait ||
            frameDesign.layout === layout.landscape ? (
              <>
                <StarMap frameDesign={frameDesign} />
                <TextContainer>
                  <TextContent outline_color={frameDesign.outlineColor}>
                    {frameText.message}
                  </TextContent>
                  <Box>
                    <TextContent outline_color={frameDesign.outlineColor}>
                      {frameText.locationName}
                    </TextContent>
                    <TextContent outline_color={frameDesign.outlineColor}>
                      {frameText.dateText}
                    </TextContent>
                    <TextContent outline_color={frameDesign.outlineColor}>
                      {frameText.lat}, {frameText.lon}
                    </TextContent>
                  </Box>
                </TextContainer>
              </>
            ) : (
              <>
                <TextContent
                  sx={{ margin: "20px 0" }}
                  outline_color={frameDesign.outlineColor}
                >
                  {frameText.message}
                </TextContent>
                <StarMap frameDesign={frameDesign} />
                <Box sx={{ marginTop: "20px" }}>
                  <TextContent outline_color={frameDesign.outlineColor}>
                    {frameText.locationName}
                  </TextContent>
                  <TextContent outline_color={frameDesign.outlineColor}>
                    {frameText.dateText}
                  </TextContent>
                  <TextContent outline_color={frameDesign.outlineColor}>
                    {frameText.lat}, {frameText.lon}
                  </TextContent>
                </Box>
              </>
            )}
          </FrameOutline>
        </FrameContainer>
      </Frame>
      {/* <IconButton
        onClick={() => htmlToImageConvert(elementRef, setIsLoading, true)}
        sx={{
          position: "fixed",
          bottom: "30px",
          right: "30px",
          zIndex: 2,
          background: "#00a4ff",
          p: "15px",
        }}
        color="white"
      >
        <FileDownloadOutlinedIcon />
      </IconButton> */}
    </>
  );
};

export default StarFrame;
