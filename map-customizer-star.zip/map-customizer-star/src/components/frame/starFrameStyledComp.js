import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";
import { layout, scaleWidth } from "../data/data";

export const Frame = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex: 1;
  min-height: 100vh;
  overflow: hidden;
  background: linear-gradient(#04050e, #474854, #04050e);
  @media (min-width: 1025px) {
    max-width: calc(100% - 500px);
  }
  @media (max-height: 700px) {
    overflow: auto;
  }
`;
export const FrameContainer = styled(Box)`
  background-color: ${({ frame_color }) => frame_color};
  padding: 30px;
  position: relative;
  transition: all 0.5s;
  transform: ${({ size }) =>
    size.width === scaleWidth.md || size.height === scaleWidth.md
      ? "scale(1)"
      : size.width === scaleWidth.lg || size.height === scaleWidth.lg
      ? "scale(1.1)"
      : size.width === scaleWidth.sm || size.height === scaleWidth.sm
      ? "scale(0.9)"
      : ""};
  @media (max-width: 830px) {
    transform: ${({ size, orientation }) =>
      orientation === layout.landscape
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.85)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.87)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.83)"
          : ""
        : ""};
  }
  @media (max-width: 720px) {
    transform: ${({ size, orientation }) =>
      orientation === layout.landscape
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.7)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.72)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.68)"
          : ""
        : orientation === layout.square
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.85)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.87)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.83)"
          : ""
        : ""};
  }
  @media (max-width: 620px) {
    transform: ${({ size, orientation }) =>
      orientation === layout.landscape
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.5)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.52)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.48)"
          : ""
        : orientation === layout.square
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.7)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.72)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.68)"
          : ""
        : size.width === scaleWidth.md || size.height === scaleWidth.md
        ? "scale(0.85)"
        : size.width === scaleWidth.lg || size.height === scaleWidth.lg
        ? "scale(0.87)"
        : size.width === scaleWidth.sm || size.height === scaleWidth.sm
        ? "scale(0.83)"
        : ""};
  }
  @media (max-width: 530px) {
    transform: ${({ size, orientation }) =>
      orientation === layout.square
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.6)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.62)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.58)"
          : ""
        : orientation === layout.portrait
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.65)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.67)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.63)"
          : ""
        : ""};
  }
  @media (max-width: 430px) {
    transform: ${({ size, orientation }) =>
      orientation === layout.landscape
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.37)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.39)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.35)"
          : ""
        : orientation === layout.square
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.43)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.45)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.41)"
          : ""
        : orientation === layout.portrait
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.5)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.57)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.53)"
          : ""
        : ""};
  }
`;
export const FrameOutline = styled(Box)`
  outline: ${({ outline_color }) => `solid 2px ${outline_color}`};
  transition: all 0.5s;
  display: flex;
  flex-flow: column;
  align-items: center;
  text-align: center;
  color: white;
  padding: 10px 0;
  box-sizing: border-box;
  height: 100%;
  height: ${({ height }) => `${height}px`};
  width: ${({ width }) => `${width}px`};
`;

export const TextContainer = styled(Box)`
  display: flex;
  justify-content: space-around;
  flex-direction: column;
  align-items: center;
  color: white;
  height: calc(100% - 302px);
`;

export const TextContent = styled(Typography)`
  font-size: 10px;
  color: ${({ outline_color }) => outline_color};
`;
export const ImageContainer = styled("img")`
  position: absolute;
  transition: all 0.4s;
  top: ${({ orientation }) =>
    orientation === layout.landscape
      ? "-44.5px"
      : orientation === layout.portrait
      ? "-60px"
      : "-51px"};
  left: ${({ orientation }) =>
    orientation === layout.landscape
      ? "-100.5px"
      : orientation === layout.portrait
      ? "-74px"
      : "-85px"};
  height: ${({ height }) => `${height}px`};
  width: ${({ width }) => `${width}px`};
`;
