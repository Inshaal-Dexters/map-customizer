import styled from "@emotion/styled";
import { Box } from "@mui/material";
import { scaleWidth, layout } from "../data/data";

export const Frame = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  flex: 1;
  min-height: 100vh;
  background: linear-gradient(#04050e, #474854, #04050e);
  overflow: hidden;

  @media (min-width: 1025px) {
    max-width: calc(100% - 500px);
  }
  
`;
export const FrameContainer = styled(Box)`
  position: relative;
  transition: all 0.5s;
  transform: ${({ frameImg, size }) =>
    frameImg
      ? size.width === scaleWidth.md || size.height === scaleWidth.md
        ? "scale(0.78)"
        : size.width === scaleWidth.lg || size.height === scaleWidth.lg
        ? "scale(0.79)"
        : size.width === scaleWidth.sm || size.height === scaleWidth.sm
        ? "scale(0.77)"
        : ""
      : size.width === scaleWidth.md || size.height === scaleWidth.md
      ? "scale(1)"
      : size.width === scaleWidth.lg || size.height === scaleWidth.lg
      ? "scale(1.1)"
      : size.width === scaleWidth.sm || size.height === scaleWidth.sm
      ? "scale(0.99)"
      : ""};
  @media (max-width: 1210px) {
    transform: ${({ orientation, frameImg, size }) =>
      orientation === layout.landscape
        ? frameImg
          ? size.width === scaleWidth.md || size.height === scaleWidth.md
            ? "scale(0.58)"
            : size.width === scaleWidth.lg || size.height === scaleWidth.lg
            ? "scale(0.59)"
            : size.width === scaleWidth.sm || size.height === scaleWidth.sm
            ? "scale(0.57)"
            : ""
          : size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.74)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.75)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.73)"
          : ""
        : ""};
  }
  @media (max-width: 1024px) {
    transform: ${({ frameImg, size }) =>
      frameImg
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.78)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.79)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.77)"
          : ""
        : size.width === scaleWidth.md || size.height === scaleWidth.md
        ? "scale(1)"
        : size.width === scaleWidth.lg || size.height === scaleWidth.lg
        ? "scale(1.1)"
        : size.width === scaleWidth.sm || size.height === scaleWidth.sm
        ? "scale(0.99)"
        : ""};
  }
  @media (max-width: 720px) {
    transform: ${({ orientation, frameImg, size }) =>
      orientation === layout.landscape
        ? frameImg
          ? size.width === scaleWidth.md || size.height === scaleWidth.md
            ? "scale(0.58)"
            : size.width === scaleWidth.lg || size.height === scaleWidth.lg
            ? "scale(0.59)"
            : size.width === scaleWidth.sm || size.height === scaleWidth.sm
            ? "scale(0.57)"
            : ""
          : size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.74)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.75)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.73)"
          : ""
        : ""};
  }

  @media (max-width: 530px) {
    transform: ${({ size, orientation, frameImg }) =>
      orientation === layout.portrait || orientation === layout.square
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.68)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.69)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.67)"
          : ""
        : frameImg
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.48)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.49)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.47)"
          : ""
        : size.width === scaleWidth.md || size.height === scaleWidth.md
        ? "scale(0.64)"
        : size.width === scaleWidth.lg || size.height === scaleWidth.lg
        ? "scale(0.65)"
        : size.width === scaleWidth.sm || size.height === scaleWidth.sm
        ? "scale(0.63)"
        : ""};
  }
  @media (max-width: 460px) {
    transform: ${({ size, frameImg, orientation }) =>
      orientation === layout.portrait || orientation === layout.square
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.58)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.59)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.57)"
          : ""
        : frameImg
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.38)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.39)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.37)"
          : ""
        : size.width === scaleWidth.md || size.height === scaleWidth.md
        ? "scale(0.54)"
        : size.width === scaleWidth.lg || size.height === scaleWidth.lg
        ? "scale(0.55)"
        : size.width === scaleWidth.sm || size.height === scaleWidth.sm
        ? "scale(0.53)"
        : ""};
  }
  @media (max-width: 390px) {
    transform: ${({ size, orientation, frameImg }) =>
      orientation === layout.portrait || orientation === layout.square
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.48)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.49)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.47)"
          : ""
        : frameImg
        ? size.width === scaleWidth.md || size.height === scaleWidth.md
          ? "scale(0.3)"
          : size.width === scaleWidth.lg || size.height === scaleWidth.lg
          ? "scale(0.31)"
          : size.width === scaleWidth.sm || size.height === scaleWidth.sm
          ? "scale(0.29)"
          : ""
        : size.width === scaleWidth.md || size.height === scaleWidth.md
        ? "scale(0.44)"
        : size.width === scaleWidth.lg || size.height === scaleWidth.lg
        ? "scale(0.45)"
        : size.width === scaleWidth.sm || size.height === scaleWidth.sm
        ? "scale(0.43)"
        : ""};
  }
`;
export const FrameBox = styled(Box)`
  height: ${({ height }) => `${height}px`};
  width: ${({ width }) => `${width}px`};
`;
export const Image = styled("img")`
  position: absolute;
  transition: all 0.4s;
  pointer-events: none;
  top: ${({ orientation }) =>
    orientation === layout.landscape
      ? "-49.5px"
      : orientation === layout.portrait
      ? "-70px"
      : "-50px"};
  left: ${({ orientation }) =>
    orientation === layout.landscape
      ? "-100.5px"
      : orientation === layout.portrait
      ? "-81px"
      : "-83px"};
  height: ${({ height }) => `${height}px`};
  width: ${({ width }) => `${width}px`};
`;
