import ClassicMapFrame from "./worldMapFrames/classicMapFrame/classicMapFrame";
import CleanMapFrame from "./worldMapFrames/cleanMapFrame/cleanMapFrame";
import InstaMapFrame from "./worldMapFrames/instaMapFrame/instaMapFrame";
import LabelMapFrame from "./worldMapFrames/labelMapFrame/labelMapFrame";
import YoungMapFrame from "./worldMapFrames/youngMapFrame/youngMapFrame";
import FileDownloadOutlinedIcon from "@mui/icons-material/FileDownloadOutlined";
import WorldMap from "../worldMap/worldMap";
import {
  Frame,
  FrameBox,
  FrameContainer,
  Image,
} from "./worldMapFramesStyledComp";
import BoldMapFrame from "./worldMapFrames/boldMapFrame.jsx/boldMapFrame";
import ElegantMapFrame from "./worldMapFrames/elegantMapFrame/elegantMapFrame";
import CircleMapFrame from "./worldMapFrames/circleMapFrame/circleMapFrame";
import { layout, types } from "../data/data";
import { IconButton } from "@mui/material";
import Loader from "../loader/loader";
import { htmlToImageConvert } from "../../commons/imgConverter";

const WorldMapFrames = ({ frameDesign, frameText, setFrameDesign,isLoading,setIsLoading,elementRef }) => {

  const CustomFrame = ({ frameDesign, frameText }) => {
    let frame = <></>;
    switch (frameDesign.frameStyle) {
      case "Classic":
        frame = (
          <ClassicMapFrame
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
          />
        );
        break;
      case "Label":
        frame = (
          <LabelMapFrame
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
          />
        );
        break;
      case "Young":
        frame = (
          <YoungMapFrame
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
          />
        );
        break;
      case "Insta":
        frame = (
          <InstaMapFrame
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
          />
        );
        break;
      case "Clean":
        frame = (
          <CleanMapFrame
            orientation={frameDesign.layout}
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
          />
        );
        break;
      case "Bold":
        frame = (
          <BoldMapFrame
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
          />
        );
        break;
      case "Elegant":
        frame = (
          <ElegantMapFrame
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
          />
        );
        break;
      case "Circle":
        frame = (
          <CircleMapFrame
            frameText={frameText}
            text_color={`rgba(${frameDesign.textColor.r},${frameDesign.textColor.g},${frameDesign.textColor.b},${frameDesign.textColor.a})`}
            frame_color={`rgba(${frameDesign.frameColor.r},${frameDesign.frameColor.g},${frameDesign.frameColor.b},${frameDesign.frameColor.a})`}
            frameDesign={frameDesign}
          />
        );
        break;

      default:
        frame = <></>;
    }
    return frame;
  };

  return (
    <>
      <Frame>
        <Loader isLoading={isLoading} />
        <FrameContainer
          orientation={frameDesign.layout}
          frameImg={frameDesign.frame.img}
          size={frameDesign.size}
        >
          {frameDesign.type !== types.frame || frameDesign.frame.img === "" ? (
            <></>
          ) : (
            <Image
              src={frameDesign.frame.img}
              alt="frame"
              orientation={frameDesign.layout}
              height={
                frameDesign.layout === layout.square
                  ? 600
                  : frameDesign.layout === layout.landscape
                  ? 599.5
                  : 840
              }
              width={
                frameDesign.layout === layout.square
                  ? 666
                  : frameDesign.layout === layout.landscape
                  ? 914.5
                  : 664
              }
            />
          )}
          <FrameBox
            ref={elementRef}
            height={
              frameDesign.layout === layout.square
                ? 500
                : frameDesign.layout === layout.landscape
                ? 500
                : 700
            }
            width={
              frameDesign.layout === layout.square
                ? 500
                : frameDesign.layout === layout.landscape
                ? 700
                : 500
            }
          >
            <WorldMap
              frameDesign={frameDesign}
              setFrameDesign={setFrameDesign}
            />
            <CustomFrame frameDesign={frameDesign} frameText={frameText} />
          </FrameBox>
        </FrameContainer>
      </Frame>
      <IconButton
        onClick={() => htmlToImageConvert(elementRef, setIsLoading,true)}
        sx={{
          position: "fixed",
          bottom: "30px",
          right: "30px",
          zIndex: 2,
          background: "#00a4ff",
          p: "15px",
        }}
        color="white"
      >
        <FileDownloadOutlinedIcon />
      </IconButton>
    </>
  );
};

export default WorldMapFrames;
