import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";

const CircleMapFrame = ({
  frameDesign,
  frameText,
  text_color,
  frame_color,
}) => {
  return (
    <CircleMapContainer text_color={text_color} frame_color={frame_color}>
      <svg viewBox="-10 -1 30 100" id="circlesize" style={{}}>
        {frameDesign.layout === "landscape" ? (
          <path d="M-15 -1 H40 V100 H-10z M 5 6.5 m -7, 0 a 7,7 0 1,0 14,0 a 7,7 0 1,0 -14,0z"></path>
        ) : frameDesign.layout === "portrait" ? (
          <path d="M-15 -1 H40 V100 H-10z M 5 14 m -12.5, 0 a 12.5,12.5 0 1,0 25,0 a 12.5,12.5 0 1,0 -25,0z"></path>
        ) : (
          <path d="M-15 -1 H40 V100 H-10z M 5 10 m -10, 0 a 10,10 0 1,0 20,0 a 10,10 0 1,0 -20,0z"></path>
        )}
      </svg>
      <CircleTextContainer text_color={text_color} frame_color={frame_color}>
        <TextContent
          variant="h2"
          sx={{
            fontSize: "23px",
            fontWeight: 400,
          }}
        >
          {frameText.title}
        </TextContent>

        <TextContent
          variant="h3"
          sx={{
            fontSize: "18px",
            fontWeight: 200,
            marginTop: "5px",
          }}
        >
          {frameText.subTitle}
        </TextContent>

        <TextContent
          variant="h4"
          sx={{
            fontSize: "14px",
            marginTop: "5px",
          }}
        >
          {frameText.lon} N {frameText.lat} E
        </TextContent>
      </CircleTextContainer>
    </CircleMapContainer>
  );
};
export default CircleMapFrame;

const CircleMapContainer = styled(Box)`
  position: absolute;
  overflow: hidden;
  top: 0;
  width: 100%;
  height: 100%;
  svg {
    fill: ${({ frame_color }) => frame_color};
  }
  pointer-events: none;
  z-index: 2;
`;
const TextContent = styled(Typography)`
  letter-spacing: "5px";
  text-transform: uppercase;
`;

const CircleTextContainer = styled(Box)`
  position: absolute;
  bottom: 40px;
  transition: all 0.5s;
  text-align: center;
  width: 100%;
  margin: 0 auto;
  z-index: 1;
  color: ${({ text_color }) => text_color};
`;
