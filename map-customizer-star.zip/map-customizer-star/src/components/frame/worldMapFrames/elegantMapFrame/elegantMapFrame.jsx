import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";

const ElegantMapFrame = ({ frameText, text_color, frame_color }) => {
  return (
    <ElegantMapContainer frame_color={frame_color}>
      <ElegantTextContainer text_color={text_color}>
        <TextContent
          variant="h2"
          sx={{
            fontSize: "22px",
            fontWeight: 400,
          }}
        >
          {frameText.title}
        </TextContent>

        <TextContent
          variant="h3"
          sx={{
            fontSize: "18px",
            fontWeight: 200,
            marginTop: "5px",
          }}
        >
          {frameText.subTitle}
        </TextContent>

        <TextContent
          variant="h4"
          sx={{
            fontSize: "14px",
            marginTop: "5px",
          }}
        >
          {frameText.lon} N {frameText.lat} E
        </TextContent>
      </ElegantTextContainer>
    </ElegantMapContainer>
  );
};

const ElegantMapContainer = styled(Box)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 50px;
  border-bottom: 190px;
  border-style: solid;
  border-color: ${({ frame_color }) => frame_color};
  pointer-events: none;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: center;
  pointer-events: none;
  z-index: 2;
`;
const TextContent = styled(Typography)`
  letter-spacing: "5px";
  text-transform: uppercase;
`;

const ElegantTextContainer = styled(Box)`
  position: absolute;
  bottom: -150px;
  transition: all 0.5s;
  text-align: center;
  color: ${({ text_color }) => text_color};
`;

export default ElegantMapFrame;
