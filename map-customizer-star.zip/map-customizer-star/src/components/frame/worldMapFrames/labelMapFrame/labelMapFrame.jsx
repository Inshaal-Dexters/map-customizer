import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";

const LabelMapFrame = ({ frameText, text_color, frame_color }) => {
  return (
    <LabelFrameContainer text_color={text_color} frame_color={frame_color}>
      <TextContent
        variant="h2"
        sx={{
          fontSize: "20px",
          fontWeight: 600,
        }}
      >
        {frameText.title}
      </TextContent>

      <TextContent
        variant="h3"
        sx={{
          fontSize: "12px",
          fontWeight: 400,
          marginTop: "5px",
        }}
      >
        {frameText.subTitle}
      </TextContent>

      <TextContent
        variant="h4"
        sx={{
          fontSize: "12px",
          marginTop: "5px",
        }}
      >
        {frameText.lon} N {frameText.lat} E
      </TextContent>
    </LabelFrameContainer>
  );
};
export default LabelMapFrame;

const LabelFrameContainer = styled(Box)`
  position: absolute;
  bottom: 40px;
  left: 50px;
  background-color: ${({ frame_color }) => frame_color};
  padding: 10px;
  border: 2px solid #000;
  pointer-events: none;
  color: ${({ text_color }) => text_color};
  z-index: 2;
`;
const TextContent = styled(Typography)`
  letter-spacing: "5px";
  line-height: 1;
  text-transform: uppercase;
  border: none;
`;
