import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";

const CleanMapFrame = ({ orientation, frameText, text_color, frame_color }) => {
  return (
    <CleanMapContainer orientation={orientation}>
      <TextContainer frame_color={frame_color}>
        <TextContent
          variant="h2"
          sx={{
            fontSize: "20px",
            fontWeight: 600,
          }}
          text_color={text_color}
        >
          {frameText.title}
        </TextContent>

        <TextContent
          variant="h3"
          sx={{
            fontSize: "12px",
            fontWeight: 400,
            paddingTop: "5px",
          }}
          text_color={text_color}
        >
          {frameText.subTitle}
        </TextContent>

        <TextContent
          variant="h4"
          sx={{
            fontSize: "12px",
            paddingTop: "5px",
          }}
          text_color={text_color}
        >
          {frameText.lon} N {frameText.lat} E
        </TextContent>
      </TextContainer>
    </CleanMapContainer>
  );
};
export default CleanMapFrame;

const CleanMapContainer = styled(Box)`
  position: absolute;
  bottom: 40px;
  transition: all 0.5s;
  width: 100%;
  margin: 0 auto;
  display: flex;
  justify-content: center;
  pointer-events: none;
  z-index: 2;
`;
const TextContainer = styled(Box)`
  padding: 15px;
  background-color: ${({ frame_color }) => frame_color};
  border: 2px solid #000;
`;
const TextContent = styled(Typography)`
  color: ${({ text_color }) => text_color};
  text-align: center;
  letter-spacing: "5px";
  text-transform: uppercase;
`;
