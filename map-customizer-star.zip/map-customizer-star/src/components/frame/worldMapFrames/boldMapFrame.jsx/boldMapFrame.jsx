import { Grid } from "@mui/material";
import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";

const BoldMapFrame = ({ frameText, text_color, frame_color }) => {
  return (
    <BoldMapContainer text_color={text_color} frame_color={frame_color}>
      <TextContent
        variant="h2"
        sx={{
          fontSize: "20px",
          fontWeight: 600,
          paddingTop: "10px",
          borderTop: "3px solid #fff",
        }}
      >
        {frameText.title}
      </TextContent>
      <Grid
        container
        sx={{
          backgroundColor: "#434343",
        }}
      >
        <Grid item xs={6}>
          <TextContent
            variant="h3"
            sx={{
              fontSize: "16px",
              fontWeight: 400,
              paddingBottom: "10px",
            }}
          >
            {frameText.subTitle}
          </TextContent>
        </Grid>
        <Grid item xs={6}>
          <TextContent
            variant="h4"
            sx={{
              fontSize: "14px",
              textAlign: "right",
              paddingBottom: "10px",
            }}
          >
            {frameText.lon} N {frameText.lat} E
          </TextContent>
        </Grid>
      </Grid>
    </BoldMapContainer>
  );
};

const BoldMapContainer = styled(Box)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 40px solid ${({ frame_color }) => frame_color};
  pointer-events: none;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  color: ${({ text_color }) => text_color};
  pointer-events: none;
  z-index: 2;
`;
const TextContent = styled(Typography)`
  letter-spacing: "5px";
  background-color: #434343;
  text-transform: uppercase;
  padding-left: 10px;
  padding-right: 10px;
`;

export default BoldMapFrame;
