import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";

const ClassicMapFrame = ({ frameText, text_color, frame_color }) => {
  return (
    <ClassicFrameContainer frame_color={frame_color}>
      <Border text_color={text_color} />
      <ClassicTextContainer text_color={text_color} frame_color={frame_color}>
        <Typography
          variant="h2"
          sx={{
            fontSize: "20px",
            fontWeight: 800,
            textTransform: "uppercase",
            letterSpacing: "0.1em",
          }}
        >
          {frameText.title}
        </Typography>
        <TextContent text_color={text_color}>{frameText.subTitle}</TextContent>
        <Typography
          sx={{
            fontSize: "12px",
          }}
        >
          {frameText.lon} N {frameText.lat} E
        </Typography>
      </ClassicTextContainer>
    </ClassicFrameContainer>
  );
};

const ClassicFrameContainer = styled(Box)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 30px solid ${({ frame_color }) => frame_color};
  pointer-events: none;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  z-index: 2;
`;
const Border = styled(Box)`
  &::before {
    content: "";
    position: absolute;
    left: -15px;
    top: -15px;
    right: -15px;
    bottom: -15px;
    pointer-events: none;
    border: 2px solid ${({ text_color }) => text_color};
  }
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 4px solid ${({ text_color }) => text_color};
  z-index: 2;
  pointer-events: none;
`;
const ClassicTextContainer = styled(Box)`
  background: linear-gradient(
    180deg,
    hsla(0, 0%, 100%, 0) 0,
    ${({ frame_color }) => frame_color} 50%,
    ${({ frame_color }) => frame_color} 0
  );
  height: 40%;
  width: 100%;
  pointer-events: none;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: ${({ text_color }) => text_color};
`;
const TextContent = styled(Typography)`
  &::before {
    background-color: ${({ text_color }) => text_color};
    content: "";
    display: inline-block;
    height: 0.1em;
    position: relative;
    vertical-align: middle;
    width: 35px;
    right: 0.7em;
  }
  font-size: 12px;
  font-weight: 400;
  padding-top: 0.15em;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  pointer-events: none;

  &::after {
    background-color: ${({ text_color }) => text_color};
    content: "";
    display: inline-block;
    height: 0.1em;
    position: relative;
    vertical-align: middle;
    width: 35px;
    left: 0.5em;
  }
`;

export default ClassicMapFrame;
