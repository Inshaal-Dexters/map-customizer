import { Grid } from "@mui/material";
import styled from "@emotion/styled";
import { Box } from "@mui/material";

const YoungMapFrame = ({ frameText, text_color, frame_color }) => {
  return (
    <YoungFrameContainer frame_color={frame_color}>
      <Grid container sx={{ background: " white", padding: "8px 5px" }}>
        <Grid item xs={6}>
          <TextContent
            variant="h2"
            sx={{
              fontSize: "20px",
              fontFamily: "Sedgwick Ave",
              fontWeight: 800,
              letterSpacing: "2px",
            }}
            text_color={text_color}
          >
            {frameText.title}
          </TextContent>
        </Grid>
        <Grid item xs={6} sx={{ textAlign: "right" }}>
          <TextContent
            sx={{ fontSize: "16px", fontWeight: "400px" }}
            text_color={text_color}
          >
            {frameText.subTitle}
          </TextContent>
          <TextContent
            sx={{ fontSize: "14px", fontWeight: "400px" }}
            text_color={text_color}
          >
            {frameText.lat} N {frameText.lon} E
          </TextContent>
        </Grid>
      </Grid>
    </YoungFrameContainer>
  );
};
export default YoungMapFrame;

const YoungFrameContainer = styled(Box)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 40px solid ${({ frame_color }) => frame_color};
  pointer-events: none;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
`;
const TextContent = styled(Box)`
  color: ${({ text_color }) => text_color};
  text-transform: uppercase;
`;
