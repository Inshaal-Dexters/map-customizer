import styled from "@emotion/styled";
import { Box, Typography } from "@mui/material";

const InstaMapFrame = ({ frameText, text_color, frame_color }) => {
  return (
    <InstaMapContainer frame_color={frame_color}>
      <TextContent
        variant="h2"
        sx={{
          fontSize: "20px",
          fontWeight: 600,
          paddingTop: "10px",
          borderTop: "4px solid #000",
        }}
        frame_color={frame_color}
        text_color={text_color}
      >
        {frameText.title}
      </TextContent>

      <TextContent
        variant="h3"
        sx={{
          fontSize: "12px",
          fontWeight: 400,
          paddingTop: "5px",
        }}
        frame_color={frame_color}
        text_color={text_color}
      >
        {frameText.subTitle}
      </TextContent>

      <TextContent
        variant="h4"
        sx={{
          fontSize: "12px",
          paddingTop: "5px",
        }}
        frame_color={frame_color}
        text_color={text_color}
      >
        {frameText.lon} N {frameText.lat} E
      </TextContent>
    </InstaMapContainer>
  );
};
export default InstaMapFrame;

const InstaMapContainer = styled(Box)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 40px solid ${({ frame_color }) => frame_color};
  pointer-events: none;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  z-index: 1;
`;
const TextContent = styled(Typography)`
  letter-spacing: "5px";
  line-height: 1;
  text-transform: uppercase;
  background-color: ${({ frame_color }) => frame_color};
  color: ${({ text_color }) => text_color};
`;
