import { Frame, Jpg, Mural } from "./svg/svg";

import HomeIcon from "@mui/icons-material/Home";
import FavoriteIcon from "@mui/icons-material/Favorite";
import VolunteerActivismIcon from "@mui/icons-material/VolunteerActivism";
import StarIcon from "@mui/icons-material/Star";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import FlatwareIcon from "@mui/icons-material/Flatware";
import WcIcon from "@mui/icons-material/Wc";
import LocalHotelIcon from "@mui/icons-material/LocalHotel";
import BeachAccessIcon from "@mui/icons-material/BeachAccess";
import EmojiEmotionsIcon from "@mui/icons-material/EmojiEmotions";
import FlightIcon from "@mui/icons-material/Flight";
import SchoolIcon from "@mui/icons-material/School";

export const types = {
  mural: "Mural",
  frame: "Poster",
  jpg: "Digital File",
};

export const layout = {
  portrait: "portrait",
  landscape: "landscape",
  square: "square",
};

export const scaleWidth = { sm: 12, md: 20, lg: 24 };

export const starData = {
  type: [
    { name: types.mural, svg: <Mural /> },
    { name: types.frame, svg: <Frame /> },
    { name: types.jpg, svg: <Jpg /> },
  ],
  material: {
    [types.mural]: [
      {
        title: "Traditional HP pre-pasted Wallpaper",
        rate: 6.75,
        discription:
          "Its high definition print surface and ultra smooth finish is ideal for a vivid print. Water activated adhesive backing. Designed for easy application and clean removal. ",
        points: [
          "Eco Friendly - Recyclable (PVC Free)",
          "Easy to Install, Easy to remove",
          "For flat & smooth surface application",
          "Class A Fire Rating",
          "FSC Certified",
        ],
        brand: [
          {
            title: "Brand: HP or equivalent",
            points: [
              "Finish : 	Matte",
              "Weight : 175 g/m²",
              "Thickness : 7 mil",
            ],
          },
        ],
      },
      {
        title: "Korographics Wallpaper unpasted",
        rate: 6.75,
        discription:
          "Matte white media paper for high resolution image reproduction. Unpasted (paste not included).",
        points: [
          "Professional installation recommended.",
          "For flat & smooth surface application.",
          "Class A Fire Rating.",
        ],
        brand: [
          {
            title: "Brand : Korographics or equivalent",
            points: [
              "Finish : 	available in Matte, Abaco Beach and Glassed out ",
              "Thickness : 18 to 26 mil ",
            ],
          },
        ],
      },
      {
        title: "Peel & Stick Fabric Material Photo Tex",
        rate: 8.25,
        discription:
          "Photo Tex is a peel & stick fabric material that is removable and repositionable without damage and has a slight canvas matte finish. Best for commercial use.",
        points: [
          "Easy to Install. Easy to remove and reposition.",
          "For flat & smooth surface application",
          "Class A Fire Rating.",
        ],
        brand: [
          {
            title: "Brand : Orafol or equivalent",
            points: ["Finish : 	Matte ", "Opaque: 99 percent block out"],
          },
        ],
      },
      {
        title: "Peel and Stick Vinyl Laminated with Matte Lamination",
        rate: 8.25,
        discription: "Peel & Stick easy to install. Best for commercial use.",
        points: [
          "Premium Calendared Vinyl film",
          "Easy to Install, Easy to remove",
          "For flat & smooth surface application",
          "Class A Fire Rating.",
        ],
        brand: [
          {
            title: "Brand : Orafol or equivalent",
            points: ["Finish : 	Matte ", "Thickness : 4 mil"],
          },
        ],
      },
      {
        title:
          "Peel and stick Vinyl Laminated with Dry Erase Lamination [for dry erase marker]",
        rate: 12.75, //convert rate
        discription:
          "Peel & Stick easy to install. It has a smooth semi-gloss finish. Our extra lamination allows for use of dry-erase markers. Our customers find it a perfect management and organizational tool transposing operational objectives to visual mapping. ",
        points: [
          "Premium Cast Vinyl film",
          "Easy to Install, Easy to remove",
          "For flat & smooth surface application",
          "Class A Fire Rating.",
          "Premium Calendared Vinyl film",
          "Easy to Install, Easy to remove",
          "For flat & smooth surface application",
          "Class A Fire Rating",
        ],
        brand: [
          {
            title: "Brand : Orafol or equivalent",
            points: ["Finish : 	Gloss", "Thickness : 4 mil "],
          },
        ],
      },
      {
        title:
          "Peel and stick Vinyl Laminated with Matte Lamination [for textured wall",
        rate: 13.25, // convert to meter square
        discription:
          "For brilliant and colourful outdoor advertising. Can be applied to flat or simple curved unsealed textured surfaces, such as brick, concrete block and poured concrete. Through the use of heat, the film can also be applied to structured surfaces and into gaps. It has a smooth matte finish. ",
        points: [
          "Premium Cast Vinyl film",
          "Easy to Install, Easy to remove",
          "For textured surface application",
          "Class A Fire Rating.",
        ],
        brand: [
          {
            title: "Brand : Orafol or equivalent",
            points: ["Finish : 	Matte ", "Thickness : &gt;2 mil "],
          },
        ],
      },
    ],
    [types.frame]: [
      {
        title: "Printed poster",
        rate: 36.76,
        discription:
          "Museum-quality posters, giclée-printed on archival, acid-free thick paper that yields brilliant prints to brighten up any room. Known for its scratch resistance, wet strength, and bright white finish. ",
        brand: [
          {
            title: "Brand : SIHL or equivalent",
            points: [
              "Finish : Semi-Gloss ",
              "Weight : 200 g/m² ",
              "Thickness : 8 mil ",
              "Blank product sourced from Japan",
              "FSC Certified",
            ],
          },
        ],
      },
      {
        title: "Printed poster Top Laminated",
        rate: 10.75,
        discription:
          "Museum-quality posters, giclée-printed on archival, acid-free thick paper that yields brilliant prints to brighten up any room. Known for its scratch resistance, wet strength, and vivid white finish. ",
        brand: [
          {
            title: "Brand : SIHL or equivalent",
            points: [
              "Finish : Matte ",
              "Weight : 200 g/m² ",
              "Thickness : &gt;8 mil ",
              "Blank product sourced from Japan",
              "FSC Certified",
            ],
          },
        ],
      },
      {
        title: "Printed poster Top laminated with DRY ERASE Overlaminate",
        rate: 10.75,
        discription:
          "Museum-quality posters, giclée-printed on archival, acid-free thick paper. Our extra lamination allows for use of dry-erase markers. Our customers find it a perfect management and organizational tool transposing operational objectives to visual mapping.",
        brand: [
          {
            title: "Brand : SIHL or equivalent",
            points: [
              "Finish : Semi-Gloss ",
              "Weight : 200 g/m² ",
              "Thickness : &gt;8 mil ",
              "Blank product sourced from Japan",
              "FSC Certified",
            ],
          },
        ],
      },
    ],
    [types.jpg]: [
      {
        title: "Digital file PDF",
        rate: 29,
        discription: "Digital file PDF @300dpi PNG",
      },
    ],
  },
  size: {
    [layout.square]: [
      { width: 12, height: 12 },
      { width: 20, height: 20 },
      { width: 24, height: 24 },
    ],
    [layout.portrait]: [
      { width: 12, height: 16 },
      { width: 20, height: 28 },
      { width: 24, height: 32 },
    ],
    [layout.landscape]: [
      { width: 16, height: 12 },
      { width: 28, height: 20 },
      { width: 32, height: 24 },
    ],
  },
  layout: [layout.portrait, layout.landscape, layout.square],
  colorData: [
    { color: "#040b4a", colorName: "Blue" },
    { color: "#093804", colorName: "Green" },
    { color: "#0a0a0a", colorName: "Black" },
    { color: "#3e0531", colorName: "Pink" },
    { color: "#4d1306", colorName: "Maroon" },
  ],
  frames: [
    {
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701432729/frame/tbdc04r8m6w44mgj18s7.png",
      name: "Oak Black",
      price: 33,
    },
    {
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701432730/frame/aurwb4pwjnkuu9eqob4d.png",
      name: "Oak White",
      price: 33,
    },
    {
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701432730/frame/mkdtvqeafv7cxqsqubmg.png",
      name: "Oak JacoBean",
      price: 33,
    },
    {
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701432730/frame/dwrmyj24vxmngbkkmhpt.png",
      name: "Oak Light",
      price: 33,
    },
    {
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701432730/frame/wjfesbstl91mlqaek6lj.png",
      name: "Oak Pale Grey",
      price: 33,
    },
  ],
};

export const mapData = {
  frameStyle: [
    {
      name: "Classic",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434079/frame%20style/xkphra0kn3cpxbkkjqgx.png",
    },
    {
      name: "Label",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434080/frame%20style/hez4pcigl6bnuk7zqdqt.png",
    },
    {
      name: "Insta",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434080/frame%20style/f9peasy9ir3m6igzyjaa.png",
    },
    {
      name: "Clean",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434079/frame%20style/xxfmtcplsydx5ial0e87.png",
    },
    {
      name: "Young",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434079/frame%20style/damxht4i3n6e9lhianpb.png",
    },
    {
      name: "Bold",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434078/frame%20style/lbmghqs1gnrirzermqhq.png",
    },
    {
      name: "Elegant",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434079/frame%20style/rjn6ventlv8aaipaocrg.png",
    },
    {
      name: "Circle",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434079/frame%20style/jx4yu56evrerygdixos4.png",
    },
  ],
  mapStyle: [
    {
      name: "Blue Print",
      link: "huzaifa-sattar1/clnxhbh3o002v01qx6wr55eoz",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434664/map/gevm9astoabzi8whtxk1.png",
    },
    {
      name: "Standard oily",
      link: "huzaifa-sattar1/clnxh3dhx007p01qm1fpx0fj5",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434669/map/wjhuieeidstlfvkaczcn.png",
    },
    {
      name: "Glow Glob",
      link: "huzaifa-sattar1/clnxh1bbj007o01qmek8e4y2a",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434664/map/jojimi2yl6fncihafptn.png",
    },
    {
      name: "Unicorn",
      link: "huzaifa-sattar1/clnxgyiex007i01qxfskif97t",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434667/map/yjutnba1v7maumk2v78l.png",
    },
    {
      name: "Basic Overcast",
      link: "huzaifa-sattar1/clnxgxfy2007h01qxamzt7oix",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434665/map/ic0d5pjzcfbhmmyrnydc.png",
    },
    {
      name: "Basic Dark",
      link: "huzaifa-sattar1/clnxgt3th007n01qm2wx9gqhg",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434664/map/vvr8xkgxomohnecjrpvr.png",
    },
    {
      name: "Navigation",
      link: "huzaifa-sattar1/clnogp2fu005501pa0klndheo",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434664/map/rwzxqah4zdy8yd0lgysm.png",
    },
    {
      name: "Streets View",
      link: "huzaifa-sattar1/clnxdr9i7002h01qxhcyr2nus",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434667/map/jgdc7ylhw9bedph5o4id.png",
    },
    {
      name: "Modified Street",
      link: "huzaifa-sattar1/clnxem4x5002m01qxcfiha6rs",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434663/map/gtfb2guk7hhryqplwbnl.png",
    },
    {
      name: "Satellite view",
      link: "huzaifa-sattar1/clnxdomex006y01qvf4sm8jpj",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434680/map/dou8ethgvnfca9fv0jqy.png",
    },
    {
      name: "Monochrome view",
      link: "huzaifa-sattar1/clnd9fdy603un01r7bt0q9e1m",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434664/map/v2pgp4mqzfsot5js9nth.png",
    },
    {
      name: "Navigation Basic",
      link: "huzaifa-sattar1/clnnbw5cc008w01qp19pg8l9s",
      img: "https://res.cloudinary.com/dbrgsqz5h/image/upload/v1701434667/map/zhhcwxqr9ghvc67ybu5o.png",
    },
  ],

  markerIcons: [
    <LocationOnIcon />,
    <FavoriteIcon />,
    <HomeIcon />,
    <VolunteerActivismIcon />,
    <StarIcon />,
    <LocalHotelIcon />,
    <WcIcon />,
    <FlatwareIcon />,
    <SchoolIcon />,
    <BeachAccessIcon />,
    <EmojiEmotionsIcon />,
    <FlightIcon />,
  ],
};
