import { useEffect, useRef } from "react";
import celestial from "d3-celestial";
import { Box } from "@mui/material";
import { MapContainer } from "./starMapStyledComp";

const Celestial = celestial.Celestial();
window.Celestial = Celestial;

const StarMap = ({ frameDesign }) => {
  const mapRef = useRef();
  const FONT = "Raleway";
  const config = {
    container: "map",
    width: 2048,

    form: false,
    advanced: false,
    interactive: false,
    disableAnimations: true,

    zoomlevel: null,
    zoomextend: 1,

    projection: "airy",
    transform: "equatorial",

    follow: "zenith",

    lines: {
      graticule: { show: frameDesign.grid, width: 4, opacity: 0.2 },
      equatorial: { show: false },
      ecliptic: { show: false },
      galactic: { show: false },
      supergalactic: { show: false },
    },
    datapath: "https://ofrohn.github.io/data/",
    planets: {
      show: false,
    },

    dsos: {
      show: false,
      names: false,
    },

    constellations: {
      names: false,
      namesType: "iau",
      nameStyle: {
        fill: "#ffffff",
        align: "center",
        baseline: "middle",
        font: [`6px ${FONT}`, `4px ${FONT}`, `0px ${FONT}`],
      },
      lines: frameDesign.constellation,
      lineStyle: { stroke: frameDesign.strokeColor, width: 4, opacity: 0.2 },
    },

    mw: {
      show: false,
      style: { fill: "#ffffff", opacity: 0.05 },
    },

    background: {
      fill: frameDesign.mapColor,
      stroke: frameDesign.strokeColor,
      opacity: 1,
      width: 8,
    },

    stars: {
      colors: false,
      size: 16,
      limit: 5.3,
      exponent: -0.28,
      style: { fill: frameDesign.starColor },
      designation: false,
      propername: false,
      propernameType: "name",
      propernameStyle: {
        fill: "#ddddbb",
        font: `8px ${FONT}`,
        align: "right",
        baseline: "center",
      },
      propernameLimit: 2.0,
    },
  };

  useEffect(() => {
    Celestial.display(config);
    mapRef.current.style.height = "auto";
  }, []);

  useEffect(() => {
    Celestial.skyview({
      date: frameDesign.date,
      location: [frameDesign.lat, frameDesign.lon],
    });
    Celestial.apply(config);
  }, [frameDesign]);

  return (
    <MapContainer id="map-container">
      <Box id="map" ref={mapRef}></Box>
    </MapContainer>
  );
};

export default StarMap;
