import styled from "@emotion/styled";
import { Box } from "@mui/material";

export const MapContainer = styled(Box)`
  #map {
    width: 302px;
    height: 302px;
  }
  canvas {
    width: 302px;
    height: 302px;
  }
`;
