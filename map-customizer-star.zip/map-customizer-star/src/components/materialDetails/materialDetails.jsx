import { List, ListItem, ListItemIcon, Typography } from "@mui/material";
import DoneIcon from "@mui/icons-material/Done";
import { starData } from "../data/data";

const MaterialDetails = ({ frameDesign }) => {
  const materialDetails = starData.material[frameDesign.type].find(
    (option) => option.title === frameDesign.material
  );

  return (
    <div>
      <Typography
        sx={{
          fontSize: "0.8rem",
          marginTop: "10px",
          display: "flex",
          justifyContent: "center",
          fontWeight: "600",
          backgroundColor: "#434343",
          color: "#ffffff",
        }}
      >
        {`Cost: ${materialDetails.rate} USD/ft²`}
      </Typography>
      <Typography sx={{ fontFamily: "revert-layer" }}>
        {materialDetails.discription}
      </Typography>
      <List>
        {materialDetails.points?.map((point, idx) => (
          <ListItem key={idx} sx={{ padding: "0", margin: "0" }}>
            <ListItemIcon>
              <DoneIcon />
            </ListItemIcon>
            {point}
          </ListItem>
        ))}
      </List>
      {materialDetails.brand?.map((brandOption, j) => (
        <div key={j}>
          <Typography
            sx={{
              fontWeight: "600",
              textAlign: "center",
              backgroundColor: "#434343",
              color: "#ffffff",
            }}
          >
            {brandOption.title}
          </Typography>
          <List sx={{ listStyle: "disc" }}>
            {brandOption.points?.map((point, idx) => (
              <ListItem key={idx} sx={{ padding: "0", margin: "0" }}>
                <ListItemIcon>
                  <DoneIcon />
                </ListItemIcon>
                {point}
              </ListItem>
            ))}
          </List>
        </div>
      ))}
    </div>
  );
};

export default MaterialDetails;
