import { useEffect, useState } from "react";
import { Box, styled } from "@mui/material";
import { layout, types } from "../data/data";
import MapDrawer from "../drawer/mapDrawer/mapDrawer";
import WorldMapFrames from "../frame/worldMapFrames";
// import { useParams, useSearchParams } from "react-router-dom";

const defaultDesignData = {
  type: types.frame,
  size: {
    width: 20,
    height: 28,
  },
  layout: layout.portrait,
  markerColor: { r: 21, g: 68, b: 109, a: 1 },
  marker: 0,
  showMarker: false,
  selectedFrame: 1,
  textColor: { r: 192, g: 189, b: 189, a: 1 },
  mapStyle: "huzaifa-sattar1/clnogp2fu005501pa0klndheo",
  frameColor: { r: 0, g: 0, b: 0, a: 1 },
  frameStyle: "Classic",
  lat: 24.9409607,
  lon: 67.1527284,
  zoom: 12,
  frame: { img: "", name: "", price: 0 },
  material: "Printed poster",
  price: 36.76,
  markerLat: 0,
  markerLon: 0,
};
const defualtTextData = {
  lat: 24.9409607,
  lon: 67.1527284,
  title: "new york",
  subTitle: "united states",
};
const MapBuilder = ({elementRef,setIsLoading,isLoading}) => {
  const [frameDesign, setFrameDesign] = useState({
    type: types.frame,
    size: {
      width: 20,
      height: 28,
    },
    layout: layout.portrait,
    markerColor: { r: 21, g: 68, b: 109, a: 1 },
    marker: 0,
    showMarker: false,
    selectedFrame: 1,
    textColor: { r: 192, g: 189, b: 189, a: 1 },
    mapStyle: "huzaifa-sattar1/clnogp2fu005501pa0klndheo",
    frameColor: { r: 0, g: 0, b: 0, a: 1 },
    frameStyle: "Classic",
    lat: 24.9409607,
    lon: 67.1527284,
    zoom: 12,
    frame: { img: "", name: "", price: 0 },
    material: "Printed poster",
    price: 36.76,
    markerLat: 0,
    markerLon: 0,
  });

  const [frameText, setFrameText] = useState({
    lat: 24.9409607,
    lon: 67.1527284,
    title: "new york",
    subTitle: "united states",
  });
  // const [searchParams, setSearchParams] = useSearchParams();

  // const params = {};

  // searchParams.forEach((value, key) => {
  //   params[key] = value;
  // });

  // useEffect(() => {
  //   console.log(params);
  // }, [searchParams]);
  useEffect(() => {
    const frameDesignData = localStorage.getItem("mapDesign");
    const frameTextData = localStorage.getItem("mapText");
    // if (searchParams !== {}) {
    //   setFrameDesign(...frameDesign, ...params);
    // } else {
    if (
      frameDesignData &&
      frameDesignData !== JSON.stringify(defaultDesignData)
    ) {
      setFrameDesign(JSON.parse(frameDesignData));
    }
    if (frameTextData && frameTextData !== JSON.stringify(defualtTextData)) {
      setFrameText(JSON.parse(frameTextData));
    }
    // }
  }, []);

  useEffect(() => {
    if (JSON.stringify(frameDesign) !== JSON.stringify(defaultDesignData)) {
      localStorage.setItem("mapDesign", JSON.stringify(frameDesign));
    }
  }, [frameDesign]);

  useEffect(() => {
    if (JSON.stringify(frameText) !== JSON.stringify(defualtTextData)) {
      localStorage.setItem("mapText", JSON.stringify(frameText));
    }
  }, [frameText]);
  return (
    <Container>
      <MapDrawer
        frameDesign={frameDesign}
        setFrameDesign={setFrameDesign}
        frameText={frameText}
        setFrameText={setFrameText}
        setIsLoading={setIsLoading}
        elementRef={elementRef}
      />
      <WorldMapFrames
        frameDesign={frameDesign}
        frameText={frameText}
        setFrameDesign={setFrameDesign}
        setIsLoading={setIsLoading}
        elementRef={elementRef}
        isLoading={isLoading}
      />
    </Container>
  );
};
const Container = styled(Box)`
  @media (min-width: 1025px) {
    display: flex;
    justify-content: flex-end;
    overflow: auto;
  }
`;
export default MapBuilder;
