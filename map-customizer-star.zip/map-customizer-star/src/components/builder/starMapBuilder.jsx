import { useEffect, useState } from "react";
import StarFrame from "../frame/starFrame";
import StarDrawer from "../drawer/starDrawer/starDrawer";
import moment from "moment";
import { Box, styled } from "@mui/material";
import { layout, types } from "../data/data";
// import { useSearchParams } from "react-router-dom";

const date = Date.now();

const defaultFrameData = {
  type: types.frame,
  size: {
    width: 20,
    height: 28,
  },
  layout: layout.portrait,
  color: "#040b4a",
  selectedFrame: 1,
  constellation: false,
  grid: false,
  date,
  frameColor: "#040b4a",
  mapColor: "#040b4a",
  outlineColor: "#ffffff",
  starColor: "#ffffff",
  strokeColor: "#ffffff",
  lat: -36.525321,
  lon: -121.815916,
  frame: { img: "", name: "", price: 0 },
  material: "Printed poster",
  price: 36.76,
};

const defaultFrameText = {
  lat: -36.525321,
  lon: -121.815916,
  locationName: "USA",
  dateText: moment(date).format("LLLL"),
  message: "The Star Sky",
};

const StarBuilder = ({elementRef,setIsLoading,isLoading}) => {
  const [frameDesign, setFrameDesign] = useState({
    type: types.frame,
    size: {
      width: 20,
      height: 28,
    },
    layout: layout.portrait,
    color: "#040b4a",
    selectedFrame: 1,
    constellation: false,
    grid: false,
    date,
    frameColor: "#040b4a",
    mapColor: "#040b4a",
    outlineColor: "#ffffff",
    starColor: "#ffffff",
    strokeColor: "#ffffff",
    lat: -36.525321,
    lon: -121.815916,
    frame: { img: "", name: "", price: 0 },
    material: "Printed poster",
    price: 36.76,
  });

  const [frameText, setFrameText] = useState({
    lat: -36.525321,
    lon: -121.815916,
    locationName: "USA",
    dateText: moment(date).format("LLLL"),
    message: "The Star Sky",
  });

  // const [searchParams, setSearchParams] = useSearchParams();

  // const params = {};

  // searchParams.forEach((value, key) => {
  //   params[key] = value;
  // });

  // useEffect(() => {
  //   console.log("searchParams", searchParams);
  //   console.log("params", params);
  // }, [searchParams]);
  useEffect(() => {
    const frameDesignData = localStorage.getItem("frameDesign");
    const frameTextData = localStorage.getItem("frameText");
    // if (searchParams !== {}) {
    //   setFrameDesign({ ...frameDesign, ...params });
    // } else {
      if (
        frameDesignData &&
        frameDesignData !== JSON.stringify(defaultFrameData)
      ) {
        setFrameDesign(JSON.parse(frameDesignData));
      }
      if (frameTextData && frameTextData !== JSON.stringify(defaultFrameText)) {
        setFrameText(JSON.parse(frameTextData));
      }
    // }
  }, []);

  useEffect(() => {
    if (JSON.stringify(frameDesign) !== JSON.stringify(defaultFrameData)) {
      localStorage.setItem("frameDesign", JSON.stringify(frameDesign));
    }
  }, [frameDesign]);

  useEffect(() => {
    if (JSON.stringify(frameText) !== JSON.stringify(defaultFrameText)) {
      localStorage.setItem("frameText", JSON.stringify(frameText));
    }
  }, [frameText]);

  return (
    <Container>
      <StarDrawer
        frameDesign={frameDesign}
        frameText={frameText}
        setFrameDesign={setFrameDesign}
        setFrameText={setFrameText}
        setIsLoading={setIsLoading}
        elementRef={elementRef}
      />
      <StarFrame frameDesign={frameDesign} frameText={frameText}
      setIsLoading={setIsLoading}
      elementRef={elementRef}
      isLoading={isLoading}
      />
    </Container>
  );
};
const Container = styled(Box)`
  @media (min-width: 1025px) {
    display: flex;
    justify-content: flex-end;
  }
`;
export default StarBuilder;
