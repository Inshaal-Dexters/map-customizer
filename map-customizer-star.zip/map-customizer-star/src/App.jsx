import StarBuilder from "./components/builder/starMapBuilder";
import "./app.css";
// import MapBuilder from "./components/builder/cityMapBuilder";
import { useRef, useState } from "react";

const App = () => {
  const elementRef = useRef(null);
  const [isLoading, setIsLoading] = useState(false);
  return (
    <StarBuilder
      elementRef={elementRef}
      setIsLoading={setIsLoading}
      isLoading={isLoading}
    />
  );
};

export default App;
