import { toBlob, toJpeg } from "html-to-image";
import imageCompression from "browser-image-compression";

export const base64ToBlob = async (base64String) => {
  return fetch(base64String).then((res) => res.blob());
};

export const compressImage = async (imageFile) => {
  const options = {
    maxSizeMB: 1,
    maxWidthOrHeight: 800,
  };
  try {
    const compressedFile = await imageCompression(imageFile, options);
    console.log(compressedFile.size / 1024 / 1024);
    return compressedFile;
  } catch (error) {
    console.log(error);
  }
};

export const htmlToImageConvert = (
  elementRef,
  setIsLoading,
  download = false
) => {
  return new Promise((resolve, reject) => {
    elementRef.current.style.transform = "scale(1)";
    setIsLoading(true);
    setTimeout(() => {
      toJpeg(elementRef.current, { cacheBust: false, pixelRatio: 8 })
        .then(async (dataUrl) => {
          if (download) {
            const link = document.createElement("a");
            link.download = "image.jpg";
            link.href = dataUrl;
            link.click();
          }

          setTimeout(() => {
            elementRef.current.style.transform = "";
            setIsLoading(false);
            resolve(dataUrl);
          });
        })
        .catch((err) => {
          setIsLoading(false);
          reject(err);
        });
    });
  });
};

export const htmlToBlobConvert = (elementRef) => {
  return new Promise((resolve, reject) => {
    elementRef.current.style.transform = "scale(1)";
    setTimeout(() => {
      toBlob(elementRef.current, { cacheBust: false, pixelRatio: 8 })
        .then(async (blob) => {
          if (window.saveAs) {
            window.saveAs(blob, "my-node.png");
          }

          setTimeout(() => {
            elementRef.current.style.transform = "";
            resolve(blob);
          });
        })
        .catch((err) => {
          reject(err);
        });
    });
  });
};
