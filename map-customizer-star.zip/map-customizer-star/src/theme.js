// eslint-disable
import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: {
      main: "#434343",
    },
    secondary: {
      main: "#ff4081",
    },
    white: {
      main: "#ffffff",
    },
  },
});

export default theme;
