import axios from "axios";

export const scrapData = async (
  frameDesign,
  totalPrice,
  blob,
  setIsLoading
) => {
  const {
    type,
    size: { width, height },
    layout,
    frame: { name },
    material,
  } = frameDesign;

  const data = {
    type,
    width,
    height,
    layout,
    frameName: name,
    material,
    totalPrice,
  };

  const formData = new FormData();

  for (var key in data) {
    formData.append(key, data[key]);
  }
  formData.append("product", "star");
  formData.append("file", blob);
  try {
    const res = await axios.post(
      "https://makemymaps.com/wp-json/product/v1/add_to_cart",
      formData
    );
    if (res.status === 200) {
      setIsLoading(false);
      window.location = "https://makemymaps.com/cart/";
    }
  } catch (err) {
    setIsLoading(false);
    console.log("error", err);
  }
};
